package lms;

import java.util.Arrays;

public class Library {
    private Book[] books;
    private int count;

    public Library(int capacity) {
        books = new Book[capacity];
        count = 0;
    }

    // Add a new book
    public void addBook(Book book) {
        if (count >= books.length) {
            System.out.println("Library is full. Cannot add more books.");
            return;
        }
        books[count++] = book;
    }

    // Linear search to find books by title
    public Book linearSearchByTitle(String title) {
        for (int i = 0; i < count; i++) {
            if (books[i].getTitle().equalsIgnoreCase(title)) {
                return books[i];
            }
        }
        return null;
    }

    // Binary search to find books by title (assuming the list is sorted)
    public Book binarySearchByTitle(String title) {
        Arrays.sort(books, 0, count, (a, b) -> a.getTitle().compareToIgnoreCase(b.getTitle()));
        int left = 0;
        int right = count - 1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            int comparison = books[mid].getTitle().compareToIgnoreCase(title);
            if (comparison == 0) {
                return books[mid];
            }
            if (comparison < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null;
    }

    public void printAllBooks() {
        for (int i = 0; i < count; i++) {
            System.out.println(books[i]);
        }
    }

    public static void main(String[] args) {
        Library library = new Library(10);

        // Adding books
        library.addBook(new Book(1, "The Great Gatsby", "F. Scott Fitzgerald"));
        library.addBook(new Book(2, "Moby Dick", "Herman Melville"));
        library.addBook(new Book(3, "To Kill a Mockingbird", "Harper Lee"));

        // Linear search for a book
        String searchTitle = "Moby Dick";
        Book foundBook = library.linearSearchByTitle(searchTitle);
        System.out.println("Linear Search - Book found: " + foundBook);

        // Binary search for a book
        foundBook = library.binarySearchByTitle(searchTitle);
        System.out.println("Binary Search - Book found: " + foundBook);

        // Print all books
        System.out.println("All books in the library:");
        library.printAllBooks();
    }
}
