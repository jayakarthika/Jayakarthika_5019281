package ims;

public class Main {
    public static void main(String[] args) {
        InventoryManagementSystem ims = new InventoryManagementSystem();

        
        Product product1 = new Product("1", "Laptop", 10, 999.99);
        Product product2 = new Product("2", "Smartphone", 50, 599.99);
        ims.addProduct(product1);
        ims.addProduct(product2);

       
        Product updatedProduct1 = new Product("1", "Laptop", 8, 999.99);
        ims.updateProduct("1", updatedProduct1);

        
        ims.deleteProduct("2");

        
        Product retrievedProduct = ims.getProduct("1");
        System.out.println("Retrieved Product: " + retrievedProduct.getProductName());
    }
}

