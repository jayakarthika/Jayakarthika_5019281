package ecp;

import java.util.Arrays;
import java.util.Comparator;

public class Main {

    public static void main(String[] args) {
        Product[] products = {
            new Product("1", "Laptop", "Electronics"),
            new Product("2", "Smartphone", "Electronics"),
            new Product("3", "Tablet", "Electronics"),
            new Product("4", "Headphones", "Accessories"),
            new Product("5", "Charger", "Accessories")
        };

        // Linear search
        Product foundProduct = SearchAlgorithms.linearSearch(products, "Tablet");
        if (foundProduct != null) {
            System.out.println("Product found: " + foundProduct.getProductName());
        } else {
            System.out.println("Product not found.");
        }

        // Sort products for binary search
        SearchAlgorithms.sortProductsByName(products);

        // Binary search
        foundProduct = SearchAlgorithms.binarySearch(products, "Tablet");
        if (foundProduct != null) {
            System.out.println("Product found: " + foundProduct.getProductName());
        } else {
            System.out.println("Product not found.");
        }
    }
}
