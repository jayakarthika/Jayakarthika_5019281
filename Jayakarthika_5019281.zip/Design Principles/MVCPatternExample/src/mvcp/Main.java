package mvcp;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Student model = new Student("1", "John Doe", "A");

        
        StudentView view = new StudentView();

        
        StudentController controller = new StudentController(model, view);

        
        controller.updateView();

        
        controller.setStudentName("Jane Doe");
        controller.setStudentGrade("B");
        controller.updateView();

	}

}
