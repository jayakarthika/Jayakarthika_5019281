package ppe;

public interface Image {
	void display();

}
