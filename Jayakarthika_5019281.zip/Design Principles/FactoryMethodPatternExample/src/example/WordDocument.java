package example;

public interface WordDocument {
    void open();
    void save();
}
