package example;

public interface ExcelDocument {
    void open();
    void save();
}
