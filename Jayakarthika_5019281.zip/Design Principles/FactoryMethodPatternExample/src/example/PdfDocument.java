package example;

public interface PdfDocument {
    void open();
    void save();
}


