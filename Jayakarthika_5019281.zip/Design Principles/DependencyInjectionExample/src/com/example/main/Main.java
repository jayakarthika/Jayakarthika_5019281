package com.example.main;

import com.example.repository.CustomerRepositoryImpl;
import com.example.service.CustomerService;

public class Main {
    public static void main(String[] args) {
        // Creating the repository implementation
        CustomerRepositoryImpl repository = new CustomerRepositoryImpl();
        
        // Injecting the repository into the service
        CustomerService service = new CustomerService(repository);
        
        // Using the service to find a customer
        String customer = service.getCustomerById(1);
        System.out.println(customer);
    }
}
