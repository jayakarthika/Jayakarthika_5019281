package com.example.repository;

public interface CustomerRepository {
	String findCustomerById(int id);

}
