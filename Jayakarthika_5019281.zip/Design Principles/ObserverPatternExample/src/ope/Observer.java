package ope;

public interface Observer {
    void update(double stockPrice);
}
